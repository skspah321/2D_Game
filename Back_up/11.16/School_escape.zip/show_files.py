import os

file_name_list = os.listdir()
for name in file_name_list:
    print(name)