<?xml version="1.0" encoding="UTF-8"?>
<tileset name="school_chip_05" tilewidth="32" tileheight="32" tilecount="36" columns="3">
 <image source="학교맵칩/왜가리/school_chip_05.png" width="96" height="384"/>
</tileset>
