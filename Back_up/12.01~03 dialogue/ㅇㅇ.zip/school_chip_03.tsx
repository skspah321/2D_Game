<?xml version="1.0" encoding="UTF-8"?>
<tileset name="school_chip_03" tilewidth="32" tileheight="32" tilecount="10" columns="2">
 <image source="학교맵칩/왜가리/school_chip_03.png" width="64" height="160"/>
</tileset>
