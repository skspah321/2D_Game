<?xml version="1.0" encoding="UTF-8"?>
<tileset name="school_chip_01" tilewidth="32" tileheight="32" tilecount="400" columns="8">
 <image source="학교맵칩/왜가리/school_chip_01.png" width="256" height="1600"/>
</tileset>
