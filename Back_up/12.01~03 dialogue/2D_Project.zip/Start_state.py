import random
import json
import os

from pico2d import *
import Game_framework
import Global_data
import Character
import Enemy
import Start_Map
import First_left_state
import First_right_state
import Second_center_state
import Dialogue_state
import Dialogue

name = "StartState"  # 처음 시작 화면

boy = None
enemy = None
Background = None
Background_image = None
dialogue = None

start_game = False

def collision(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True

def collision_right(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_right()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True

def collision_left(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_left()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True

def collision_top(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_top()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True

def collision_bottom(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_bottom()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True

def enter():
    global boy, enemy, Background, Background_image, start_game
    Background_image = load_image('image\\gradation_black.png')  # 메인 이미지

    Global_data.Start_Game = True
    Global_data.First_Floor_center = True
    start_game = True
    if Global_data.Start_Game:
        Background = Start_Map.TileMap('Maps\\1F_center.json', Start_Map.canvasWidth, Start_Map.canvasHeight)
        enemy = Enemy.Enemy() # 적
        boy = Character.Character() # 캐릭터
        boy.x = (Background.obj_data_list[0][3] + Background.obj_data_list[0][1]) // 2
        boy.y = (Background.obj_data_list[0][4] + Background.obj_data_list[0][2]) // 2


def exit():
   global Background_image
   del(Background_image)


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global start_game
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_z):
            for i in Global_data.all_obj_data:
                if i[0] == "map" and boy.state in (0, 4,):
                    if collision_top(boy, i[1], i[2], i[3], i[4]):
                        Global_data.dialogue_state = "map"
                        Game_framework.push_state(Dialogue_state)
                if i[0] == "door" and boy.state in (0, 4,):
                    if collision_top(boy, i[1], i[2], i[3], i[4]):
                        Global_data.dialogue_state = "door"
                        Game_framework.push_state(Dialogue_state)
        else:
            Background.handle_events(event)
            boy.handle_event(event)


def update(frame_time):
    global start_game

    if start_game:
        Global_data.dialogue_state = "start_game"
        Game_framework.push_state(Dialogue_state)
        start_game = False

    handle_events(frame_time)
    Background.update(frame_time)
    boy.update(frame_time)
    enemy.update(frame_time, boy.pos)
    for i in Global_data.all_obj_data:
        if i[0] == "character_left": #왼쪽 복도
            if collision(boy, i[1],i[2],i[3],i[4]):
                Game_framework.change_state(First_left_state)

        if i[0] == "wall":
            if collision_left(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(1,i[3])

            if collision_right(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(2, i[1])

            if collision_bottom(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(3, i[2])

            if collision_top(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(4, i[4])

        if i[0] == "character_right":  # 오른쪽 복도
            if collision(boy, i[1], i[2], i[3], i[4]):
                Game_framework.push_state(First_right_state)

        if i[0] == "up_start":  # 위층으로 올라감
            if collision(boy, i[1], i[2], i[3], i[4]):
                Game_framework.push_state(Second_center_state)

    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32

def draw_state():
    Background.draw()
    Background_image.draw(400, 300, 800, 600)
    enemy.draw()
    boy.draw()

def draw(frame_time):
   # Game Rendering
   clear_canvas()
   draw_state()
   #draw_rectangle(boy.left_a,boy.bottom_a,boy.right_a, boy.top_a)
   boy.draw_rec()
   enemy.draw_rec()
   update_canvas()





