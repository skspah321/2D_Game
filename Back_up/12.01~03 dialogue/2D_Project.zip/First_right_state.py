from pico2d import *
import Game_framework
import Global_data
import Character
import Enemy
import Map
import Start_Map
import First_left_state
import First_center_state
import First_right_class_state

name = "StartState"  # 처음 시작 화면

boy = None
enemy = None
Background = None


def collision(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    print("충돌!!!")

    return True

def collision_right(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_right()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    print("오른쪽 충돌!!!")

    return True

def collision_left(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_left()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    print("왼쪽 충돌!!!")

    return True

def collision_top(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_top()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    print("위쪽 충돌!!!")

    return True

def collision_bottom(a,aa,bb,cc,dd):
    left_a, bottom_a, right_a, top_a = a.get_bottom()
    left_b, bottom_b, right_b, top_b = (aa,bb,cc,dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    print("아래쪽 충돌!!!")

    return True


def enter():
    global boy, enemy, Background


    if Global_data.First_Floor_center:   # 이전 방이 중앙 현관이였다면
        Background = Map.TileMap('Maps\\1F_right.json', Map.canvasWidth, Map.canvasHeight)
        boy = Character.Character()
        boy.x = (Background.obj_data_list[10][3] + Background.obj_data_list[10][1]) // 2
        boy.y = (Background.obj_data_list[10][4] + Background.obj_data_list[10][2]) // 2

        Background.x = 0
        Background.y = 0

        for a in Global_data.all_obj_data:
            a[1] -= Background.x
            a[3] -= Background.x
            a[2] -= Background.y
            a[4] -= Background.y

    if Global_data.First_Floor_right_class:   # 이전 방이 오른쪽 교실이였다면
        Background = Map.TileMap('Maps\\1F_right.json', Map.canvasWidth, Map.canvasHeight)
        boy = Character.Character()
        boy.x = (Background.obj_data_list[8][3] + Background.obj_data_list[8][1]) // 2
        boy.y = (Background.obj_data_list[8][4] + Background.obj_data_list[8][2]) // 2

        Background.x = 0
        Background.y = 0

        for a in Global_data.all_obj_data:
            a[1] -= Background.x
            a[3] -= Background.x
            a[2] -= Background.y
            a[4] -= Background.y

    Global_data.First_Floor_right = True
    Global_data.First_Floor_center = False
    Global_data.First_Floor_left = False
    Global_data.First_Floor_center = False
    Global_data.First_Floor_left_nursing = False
    Global_data.First_Floor_right_class = False

def exit():
    pass


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        else:
            Background.handle_events(event)
            boy.handle_event(event)


def update(frame_time):
    # 현재 캐릭터 좌표, 타일위치를 저장
    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32

    handle_events(frame_time)
    Background.update(frame_time)
    boy.update(frame_time)
    #enemy.update(frame_time, boy.pos)
    for i in Global_data.all_obj_data:
        if i[0] == "character_left": # 중앙 현관으로 나감
            if collision(boy, i[1],i[2],i[3],i[4]):
                Game_framework.change_state(First_center_state)

        if i[0] == "wall":
            if collision_left(boy, i[1], i[2], i[3], i[4]):
                boy.collision(1,i[3])

            if collision_right(boy, i[1], i[2], i[3], i[4]):
                boy.collision(2, i[1])

            if collision_bottom(boy, i[1], i[2], i[3], i[4]):
                boy.collision(3, i[2])

            if collision_top(boy, i[1], i[2], i[3], i[4]):
                boy.collision(4, i[4])

        if i[0] == "enter": # 오른쪽 교실로 들어감
            if collision(boy, i[1],i[2],i[3],i[4]):
                Game_framework.change_state(First_right_class_state)

    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32

def draw(frame_time):
   # Game Rendering
   clear_canvas()
   Background.draw()
   #enemy.draw()
   boy.draw()
   #draw_rectangle(boy.left_a,boy.bottom_a,boy.right_a, boy.top_a)
   boy.draw_rec()
   #enemy.draw_rec()
   update_canvas()


