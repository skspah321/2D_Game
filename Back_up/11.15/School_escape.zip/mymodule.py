print(__name__)
