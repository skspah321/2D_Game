import game_framework
from pico2d import *

import start_state

import pause_state

import main_state

import map_01


#open_canvas()
game_framework.run(start_state)  # enter를 실행한다.
#close_canvas()