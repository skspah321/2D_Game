import random
import json
import os

from pico2d import *
import game_framework
import title_state
import map_01
import Character

name = "MainState"

boy = None
glass = None
Running = True
BackGround = None

current_time = 0.0

class Grass:
    def __init__(self):
        self.image = load_image('grass.png')

    def draw(self):
        self.image.draw(400, 30)


def enter():
    global boy,glass, current_time, Background
    Background = map_01.TileMap('Maps\\1F_center.json', map_01.canvasWidth, map_01.canvasHeight)
    current_time = get_time()
    glass = Grass()
    boy = Character.Charater()



def exit():
    global boy,glass
    del(boy)
    del(glass)


def pause():
    pass


def resume():
    pass


def handle_events():
    global Running, current_time
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            game_framework.quit()
        else:
            Background.handle_events(event)
            boy.handle_event(event)

def update():
    global current_time
    frame_time = get_frame_time()
    handle_events()
    Background.update(frame_time)
    boy.update(frame_time)
    #print(Character.Charater().width)



def draw_main_scene():
    boy.draw()


def draw():
   # Game Rendering
   clear_canvas()
   glass.draw()
   Background.draw()
   boy.draw()
   draw_rectangle(boy.left_a,boy.bottom_a,boy.right_a, boy.top_a)

   update_canvas()


def get_frame_time():
    global current_time
    frame_time = get_time() - current_time
    current_time += frame_time
    return frame_time
