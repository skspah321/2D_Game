from pico2d import*
import Character
import Global_data
import game_framework

canvasWidth = 800
canvasHeight = 600


class TileMap:
    PIXEL_PER_METER = (10.0 / 0.3)  # 10픽셀 , 30CM
    SCROLL_KMPH = 20.0  # KM / HOUR , 캐릭터가 이동하는 속도랑 맞춰줌
    SCROLL_MPM = (SCROLL_KMPH * 1000.0 / 60.0)  # 시간당 meter
    SCROLL_MPS = (SCROLL_MPM / 60.0)  # 초당 meter
    SCROLL_PPS = (SCROLL_MPS * PIXEL_PER_METER)  # 초당 픽셀, 이걸 프레임타임에 곱해준다.

    UP_RUN, RIGHT_RUN, LEFT_RUN, DOWN_RUN = 0, 1, 2, 3

    UP_STAND, RIGHT_STAND, LEFT_STAND, DOWN_STAND = 4, 5, 6, 7

    def __init__(self,filename, width, height):
        f = open(filename)
        self.map = json.load(f)  # 제이슨 파일 오픈
        self.map_width_tile = self.map["width"]  # 맵 너비 타일 개수
        self.map_height_tile = self.map["height"]  # 맵 높이 타일 개수
        self.layerindex = {"Layer_01": 0, "Layer_02": 1, "Layer_03": 2, "Object_01": 3}  # 몇번째 레이어 인지
        self.obj_data_list = []  # 오브젝트 x,y.. 좌표를 리스트로 정리
        self.obj_datas = self.map['layers'][self.layerindex["Object_01"]]['objects']

        # 오브젝트 리스트에 모든 오브젝트저장, [ 이름, x좌표, y좌표, 너비, 높이 ]
        for obj_data in self.obj_datas:
            self.obj_data_list.append([obj_data["name"], obj_data["x"],self.map_height_tile*32-obj_data["y"],
                                       obj_data["width"], obj_data["height"]])

        for obj_data in self.obj_data_list:
            obj_data[3] = obj_data[1] + obj_data[3]  # 너비 데이터를 x + 너비
            obj_data[4] = obj_data[2] - obj_data[4]  # 높이 데이터를 y - 너비

        Global_data.all_obj_data = self.obj_data_list
        self.scroll_x = 0
        self.scroll_y = 0
        self.state = 0

        self.canvasWidth = width   # 캔버스 너비 800
        self.canvasHeight = height # 캔버스 높이 600
        self.width_dir = 0  # 가로 방향 벡터
        self.height_dir = 0  # 세로 방향 벡터


        if Global_data.Right_start:
            self.x = self.map_width_tile * 32 - self.canvasWidth
            self.y = self.map_height_tile * 32 - self.canvasHeight

            for a in Global_data.all_obj_data:
                a[1] -= self.x
                a[3] -= self.x
                a[2] -= self.y
                a[4] -= self.y
        else:
            self.x = 0
            self.y = 0

            for a in Global_data.all_obj_data:
                a[1] -= 0
                a[3] -= 0
                a[2] -= 0
                a[4] -= 0

        Global_data.Right_start = False

        self.image_01 = load_image(self.map['tilesets'][0]['image'])  # 칩 1
        self.image_02 = load_image(self.map['tilesets'][1]['image'])  # 칩 2
        self.image_03 = load_image(self.map['tilesets'][2]['image'])  # 칩 3
        self.image_04 = load_image(self.map['tilesets'][3]['image'])  # 칩 4
        self.image_05 = load_image(self.map['tilesets'][4]['image'])  # 칩 5
        self.image_06 = load_image(self.map['tilesets'][5]['image'])  # 칩 6
        self.image_07 = load_image(self.map['tilesets'][6]['image'])  # 칩 7

    def clamp(self,minimum, x, maximum):
        return max(minimum, min(x, maximum))

    def draw(self):
        map_width_tile = self.map["width"]  # 맵 너비
        map_height_tile = self.map["height"]  # 맵 높이
        data_len = map_width_tile * map_height_tile  # 전체 데이터 개수

        # 레이어마다 데이터들
        data = [self.map['layers'][self.layerindex["Layer_01"]]['data'],
                self.map['layers'][self.layerindex["Layer_02"]]['data'],
                self.map['layers'][self.layerindex["Layer_03"]]['data']]

        # 각각 타일셋들 ( 맵칩 1 ~ 7 까지 순서대로 저장함 )
        tileset = [self.map['tilesets'][0], self.map['tilesets'][1], self.map['tilesets'][2],
                   self.map['tilesets'][3], self.map['tilesets'][4], self.map['tilesets'][5],
                   self.map['tilesets'][6]]

        tile_width = 32  # 한 타일의 너비 - 고정
        tile_height = 32  # 한 타일의 높이 - 고정

        # 타일 칩 마다 열의 개수 (세로가 몇개 인지)
        columns =[tileset[0]['columns'], tileset[1]['columns'], tileset[2]['columns'],
                  tileset[3]['columns'], tileset[4]['columns'], tileset[5]['columns'],
                  tileset[6]['columns']]

        # 타일 칩 마다 행의 개수 ( 가로가 몇개인지 )
        rows = [(tileset[0]['tilecount'] // columns[0]), (tileset[1]['tilecount'] // columns[1]),
                (tileset[2]['tilecount'] // columns[2]), (tileset[3]['tilecount'] // columns[3]),
                (tileset[4]['tilecount'] // columns[4]), (tileset[5]['tilecount'] // columns[5]),
                (tileset[6]['tilecount'] // columns[6])]

        # 해당 타일칩의 시작 데이터 1 , 401 , 801, 811, 947, 983, 1383
        firstgid = [tileset[0]['firstgid'], tileset[1]['firstgid'], tileset[2]['firstgid'],
                    tileset[3]['firstgid'], tileset[4]['firstgid'], tileset[5]['firstgid'],
                    tileset[6]['firstgid']]

        # 타일 배열의 시작 좌표
        #startx = (tile_width // 2) - self.x % tile_width  # x, y가 0이면 16,16 부터 찍기 시작
        #starty = tile_height // 2 - self.y % tile_height
        startx = (tile_width // 2) - self.x % tile_width
        starty = (tile_width // 2) - self.y % tile_width

        #self.x = 0
        #self.y = -20  이게 중점임 -> 이제 캐릭터로 중점을 바꿔줘야함.

        #print(self.x , self.y)

        #startx = (tile_width // 2) - All_map.character_x % tile_width  # x, y가 0이면 16,16 부터 찍기 시작
        #starty = tile_height // 2 - All_map.character_y % tile_height

        # 타일 배열의 끝 좌표
        endx = self.canvasWidth + tile_width // 2  # 816
        endy = self.canvasHeight + tile_height // 2  # 616

        #endx = self.map_width_tile * 32 + 16   # 1296
        #endy = self.map_height_tile * 32 + 16   # 656

        #print("맵 좌표: ", self.x, self.y)

        count = 0
        for i in range(3):
            desty = starty
            # my는 지금 내가 있는 좌표를 타일로 y번째 순서인지
            my = int(self.y // tile_height)
            #my = count
            #my = int(Global_data.character_y_tile - ((self.canvasHeight+40)//32 // 2))
            my = clamp(0, my, 32)
            # 가로를 먼저 찍고 위로 올라가며 찍으니까 y가 끝날때 까지
            while (desty < endy):
                destx = startx
                # mx는 지금 내가 있는 좌표를 타일로 x번째 순서인지
                mx = int(self.x // tile_width)
                #mx = count
                #mx = int(Global_data.character_x_tile - (self.canvasWidth // 32 // 2))
                mx = clamp(0,mx,32)
                #print(startx,starty,mx,my)
                # 좌 -> 우로 찍기 시작
                while (destx < endx):
                    index = (map_height_tile - my - 1) * map_width_tile + mx
                    #index = self.len[i]
                    if index > -1 and index < data_len:
                        tile = data[i][index]  # i번째 레이어 가져옴

                        if tile < firstgid[1]:
                            tile = tile - firstgid[0]
                            tx = tile % columns[0]  # 몇번째 이미지인지
                            ty = rows[0] - tile // columns[0] - 1  # 위-> 아래로 그려진걸 아래->위로
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_01.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)
                            # 가로 srcx, 세로 srcy 부터 32 만큼 사진을 잘라서 destx, desty에 그린다.

                        elif tile < firstgid[2]:
                            tile = tile - firstgid[1]
                            tx = (tile) % columns[1]  # tx는 타일번호 - 1
                            ty = rows[1] - tile // columns[1] - 1  # y값 순서 바꿔준다.
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_02.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)

                        elif tile < firstgid[3]:
                            tile = tile - firstgid[2]
                            tx = (tile) % columns[2]  # tx는 타일번호 - 1
                            ty = rows[2] - tile // columns[2] - 1  # y값 순서 바꿔준다.
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_03.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)

                        elif tile < firstgid[4]:
                            tile = tile - firstgid[3]
                            tx = (tile) % columns[3]  # tx는 타일번호 - 1
                            ty = rows[3] - tile // columns[3] - 1  # y값 순서 바꿔준다.
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_04.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)

                        elif tile < firstgid[5]:
                            tile = tile - firstgid[4]
                            tx = (tile) % columns[4]  # tx는 타일번호 - 1
                            ty = rows[4] - tile // columns[4] - 1  # y값 순서 바꿔준다.
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_05.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)

                        elif tile < firstgid[6]:
                            tile = tile - firstgid[5]
                            tx = (tile) % columns[5]  # tx는 타일번호 - 1
                            ty = rows[5] - tile // columns[5] - 1  # y값 순서 바꿔준다.
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_06.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)

                        else:
                            tile = tile - firstgid[6]
                            tx = (tile) % columns[6]  # tx는 타일번호 - 1
                            ty = rows[6] - tile // columns[6] - 1  # y값 순서 바꿔준다.
                            srcx = tx * tile_width
                            srcy = ty * tile_height
                            self.image_07.clip_draw(srcx, srcy, tile_width, tile_height, destx, desty)

                    # 한칸 찍었으면 -> 로 한칸 이동
                    destx += tile_width
                    mx += 1

                # 한줄 찍었으면 위로 한칸 이동
                desty += tile_height
                my += 1

        #모든 오브젝트 사각형 표시
        for i in Global_data.all_obj_data:
            draw_rectangle(i[1], i[2], i[3], i[4])

    def update(self, frame_time):
        distance = TileMap.SCROLL_PPS * frame_time

        if Global_data.Collision_state==False:
            if self.state == self.UP_RUN:
                self.y += (distance * self.height_dir)
                self.y = clamp(0, self.y, self.map["height"] * 32 - canvasHeight)
                if self.y > 0 and self.y < self.map["height"] * 32 - canvasHeight:
                    for a in Global_data.all_obj_data:
                        a[2] -= (self.height_dir * distance)
                        a[4] -= (self.height_dir * distance)

            elif self.state == self.RIGHT_RUN:
                self.x += (distance * self.width_dir)
                self.x = clamp(0, self.x, self.map["width"] * 32 - canvasWidth)
                if self.x > 0 and self.x < self.map["width"] * 32 - canvasWidth:
                    for a in Global_data.all_obj_data:
                        a[1] -= (self.width_dir * distance)
                        a[3] -= (self.width_dir * distance)

            elif self.state == self.LEFT_RUN:
                self.x += (distance * self.width_dir)
                self.x = clamp(0, self.x, self.map["width"] * 32 - canvasWidth)
                if self.x > 0 and self.x < self.map["width"] * 32 - canvasWidth:
                    for a in Global_data.all_obj_data:
                        a[1] -= (self.width_dir * distance)
                        a[3] -= (self.width_dir * distance)

            elif self.state == self.DOWN_RUN:
                self.y += (distance * self.height_dir)
                self.y = clamp(0, self.y, self.map["height"] * 32 - canvasHeight)
                if self.y > 0 and self.y < self.map["height"] * 32 - canvasHeight:
                    for a in Global_data.all_obj_data:
                        a[2] -= (self.height_dir * distance)
                        a[4] -= (self.height_dir * distance)




            elif self.state == self.UP_STAND:
                self.y += 0
                for a in Global_data.all_obj_data:
                    a[2] -= 0
                    a[4] -= 0

            elif self.state == self.RIGHT_STAND:
                self.x += 0
                for a in Global_data.all_obj_data:
                    a[1] -= 0
                    a[3] -= 0

            elif self.state == self.LEFT_STAND:
                self.x += 0
                for a in Global_data.all_obj_data:
                    a[1] -= 0
                    a[3] -= 0

            elif self.state == self.DOWN_STAND:
                self.y -= 0
                for a in Global_data.all_obj_data:
                    a[2] -= 0
                    a[4] -= 0

        Global_data.Collision_state= False





    def handle_events(self, event):
        if (event.type,event.key) == (SDL_KEYDOWN ,SDLK_UP):
            if self.state in (self.RIGHT_STAND,self.DOWN_STAND,self.LEFT_STAND,self.UP_STAND,self.DOWN_RUN,
                              self.LEFT_RUN,self.RIGHT_RUN):
                self.state = self.UP_RUN
                self.height_dir = 1
        elif (event.type,event.key) == (SDL_KEYDOWN ,SDLK_RIGHT):
            if self.state in (self.RIGHT_STAND, self.DOWN_STAND, self.LEFT_STAND, self.UP_STAND, self.DOWN_RUN,
                              self.LEFT_RUN,self.UP_RUN):
                self.state = self.RIGHT_RUN
                self.width_dir = 1
        elif (event.type,event.key) == (SDL_KEYDOWN ,SDLK_LEFT):
            if self.state in (self.RIGHT_STAND, self.DOWN_STAND, self.LEFT_STAND, self.UP_STAND, self.DOWN_RUN,
                              self.RIGHT_RUN,self.UP_RUN):
                self.state = self.LEFT_RUN
                self.width_dir = -1
        elif (event.type,event.key) == (SDL_KEYDOWN ,SDLK_DOWN):
            if self.state in (self.RIGHT_STAND, self.DOWN_STAND, self.LEFT_STAND, self.UP_STAND, self.RIGHT_RUN,
                              self.LEFT_RUN,self.UP_RUN):
                self.state = self.DOWN_RUN
                self.height_dir = -1
        elif (event.type,event.key) == (SDL_KEYUP ,SDLK_UP):
                if self.state in (self.UP_RUN,):
                    self.state = self.UP_STAND
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_RIGHT):
                if self.state in (self.RIGHT_RUN,):
                    self.state = self.RIGHT_STAND
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_LEFT):
                if self.state in (self.LEFT_RUN,):
                    self.state = self.LEFT_STAND
        elif (event.type, event.key) == (SDL_KEYUP, SDLK_DOWN):
                if self.state in (self.DOWN_RUN,):
                    self.state = self.DOWN_STAND

