from pico2d import *
import Game_framework
import Global_data
import Character
import Enemy
import Start_Map
import Map
import Second_center_state
import Dialogue_state

name = "2F_library_state"  # 2층 도서관

boy = None
enemy = None
Background = None


def collision(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_right(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_right()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_left(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_left()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_top(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_top()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_bottom(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_bottom()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def enter():
    global boy, enemy, Background

    if Global_data.Second_Floor_center: # 2층 현관에서 들어옴
        Background = Map.TileMap('Maps\\2F_library.json', Start_Map.canvasWidth, Start_Map.canvasHeight)
        enemy = Enemy.Enemy()  # 적
        boy = Character.Character()  # 캐릭터
        boy.x = (Background.obj_data_list[1][3] + Background.obj_data_list[1][1]) // 2
        boy.y = (Background.obj_data_list[1][4] + Background.obj_data_list[1][2]) // 2

    Global_data.Second_Floor_library = True
    Global_data.Second_Floor_center = False


def exit():
    global Background
    del (Background)


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global Running
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_z):
            for i in Global_data.all_obj_data:
                if collision(boy, i[1], i[2], i[3], i[4]):
                    if i[0] == "book":
                        Global_data.dialogue_state = "library_book"
                        Game_framework.push_state(Dialogue_state)

                    if i[0] == "research":
                        Global_data.dialogue_state = "library_research"
                        Game_framework.push_state(Dialogue_state)

                    if i[0] == "office_key" and boy.state in (0,2,4,6,):
                        if Global_data.Office_Key == False:
                            Global_data.dialogue_state = "office_key"
                            Game_framework.push_state(Dialogue_state)

                    if i[0] == "desk":
                        Global_data.dialogue_state = "library_desk"
                        Game_framework.push_state(Dialogue_state)
        else:
            Background.handle_events(event)
            boy.handle_event(event)


def update(frame_time):
    # 현재 캐릭터 좌표, 타일위치를 저장
    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32

    handle_events(frame_time)
    Background.update(frame_time)
    boy.update(frame_time)
    enemy.update(frame_time, boy.pos)
    for i in Global_data.all_obj_data:
        if i[0] == "exit":  # 중앙 현관으로 나감
            if collision(boy, i[1], i[2], i[3], i[4]):
                Game_framework.change_state(Second_center_state)

        if i[0] == "wall":
            if collision_left(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(1, i[3])

            if collision_right(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(2, i[1])

            if collision_bottom(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(3, i[2])

            if collision_top(boy, i[1], i[2], i[3], i[4]):
                Global_data.Collision_state = True
                boy.collision(4, i[4])

    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32

def draw_push_state():
    Background.draw()
    enemy.draw()
    boy.draw()


def draw(frame_time):
    # Game Rendering
    clear_canvas()
    draw_push_state()
    boy.draw_rec()
    enemy.draw_rec()
    update_canvas()


