import random
import json
import os

from pico2d import *
import Game_framework
import Global_data
import Character
import Enemy
import Start_Map
import Map
import First_center_state
import Second_library_state
import Second_office_state
import Dialogue_state

name = "2F_center_state"  # 2층 중앙 현관

boy = None
enemy = None
Background = None


def collision(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_bb()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_right(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_right()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_left(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_left()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_top(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_top()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def collision_bottom(a, aa, bb, cc, dd):
    left_a, bottom_a, right_a, top_a = a.get_bottom()
    left_b, bottom_b, right_b, top_b = (aa, bb, cc, dd)

    if left_a > right_b: return False
    if right_a < left_b: return False
    if top_a > bottom_b: return False
    if bottom_a < top_b: return False

    return True


def enter():
    global boy, enemy, Background

    if Global_data.First_Floor_center or Global_data.Start_Game: # 중앙 현관에서 올라옴
        Background = Start_Map.TileMap('Maps\\2F_center.json', Start_Map.canvasWidth, Start_Map.canvasHeight)
        enemy = Enemy.Enemy()  # 적
        boy = Character.Character()  # 캐릭터
        boy.x = (Background.obj_data_list[15][3] + Background.obj_data_list[15][1]) // 2
        boy.y = (Background.obj_data_list[15][4] + Background.obj_data_list[15][2]) // 2

    if Global_data.Second_Floor_library:  # 2층 도서관에서 나옴
        Background = Map.TileMap('Maps\\2F_center.json', Start_Map.canvasWidth, Start_Map.canvasHeight)
        enemy = Enemy.Enemy()  # 적
        boy = Character.Character()  # 캐릭터
        boy.x = (Background.obj_data_list[13][3] + Background.obj_data_list[13][1]) // 2
        boy.y = (Background.obj_data_list[13][4] + Background.obj_data_list[13][2]) // 2

    if Global_data.Second_Floor_office:  # 2층 교무실에서 나옴
        Global_data.Right_start = True
        Background = Map.TileMap('Maps\\2F_center.json', Start_Map.canvasWidth, Start_Map.canvasHeight)
        enemy = Enemy.Enemy()  # 적
        boy = Character.Character()  # 캐릭터
        boy.x = (Background.obj_data_list[12][3] + Background.obj_data_list[12][1]) // 2
        boy.y = (Background.obj_data_list[12][4] + Background.obj_data_list[12][2]) // 2

    Global_data.Second_Floor_center = True
    Global_data.First_Floor_center = False
    Global_data.Second_Floor_library = False
    Global_data.Second_Floor_office = False
    Global_data.Right_start = False
    Global_data.Start_Game = False


def exit():
    global Background
    del (Background)


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global Running
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_z):
            for i in Global_data.all_obj_data:
                if collision(boy, i[1], i[2], i[3], i[4]):
                    if i[0] == "trash":
                        Global_data.dialogue_state = "trash"
                        Game_framework.push_state(Dialogue_state)

                    if i[0] == "cleaning_tool":
                        Global_data.dialogue_state = "cleaning_tool"
                        Game_framework.push_state(Dialogue_state)

                    if i[0] == "plant":
                        Global_data.dialogue_state = "medicine"
                        Game_framework.push_state(Dialogue_state)

                    if i[0] == "left_start":
                        if Global_data.Library_Key == False:
                            Global_data.dialogue_state = "door"
                            Game_framework.push_state(Dialogue_state)

                    if i[0] == "right_start":
                        if Global_data.Office_Key == False:
                            Global_data.dialogue_state = "door"
                            Game_framework.push_state(Dialogue_state)
        else:
            Background.handle_events(event)
            boy.handle_event(event)


def update(frame_time):
    # 현재 캐릭터 좌표, 타일위치를 저장
    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32

    handle_events(frame_time)
    Background.update(frame_time)
    boy.update(frame_time)
    enemy.update(frame_time, boy.pos)
    for i in Global_data.all_obj_data:
        if i[0] == "bottom_exit":  # 중앙 현관으로 나감
            if collision(boy, i[1], i[2], i[3], i[4]):
                Game_framework.change_state(First_center_state)

        if i[0] == "right_start":  # 교무실로 들어감
            if collision(boy, i[1], i[2], i[3], i[4]):
                if Global_data.Office_Key:
                    Game_framework.change_state(Second_office_state)

        if i[0] == "left_start":  # 도서관으로 들어감
            if collision(boy, i[1], i[2], i[3], i[4]):
                if Global_data.Library_Key:
                    Game_framework.change_state(Second_library_state)

        if i[0] == "wall":
            if collision_left(boy, i[1], i[2], i[3], i[4]):
                boy.collision(1, i[3])

            if collision_right(boy, i[1], i[2], i[3], i[4]):
                boy.collision(2, i[1])

            if collision_bottom(boy, i[1], i[2], i[3], i[4]):
                boy.collision(3, i[2])

            if collision_top(boy, i[1], i[2], i[3], i[4]):
                boy.collision(4, i[4])

    Global_data.character_x = boy.x
    Global_data.character_y = boy.y
    Global_data.character_x_tile = boy.x // 32
    Global_data.character_y_tile = boy.y // 32


def draw_push_state():
    Background.draw()
    enemy.draw()
    boy.draw()


def draw(frame_time):
    # Game Rendering
    clear_canvas()
    draw_push_state()
    boy.draw_rec()
    enemy.draw_rec()
    update_canvas()


