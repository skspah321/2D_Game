from pico2d import *
import Global_data


class Dialogue:
    def __init__(self,dialogue_name):
        self.state = dialogue_name

    def update(self, frame_time):
        pass

    def draw(self):
        pass


