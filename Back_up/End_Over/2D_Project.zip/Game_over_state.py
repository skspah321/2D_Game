from pico2d import *
import Game_framework
import Global_data
import Title_state

name = "Game_over_state"  # 게임 오버

image = None
opacify_num = 0.0

def clamp(minimum, x, maximum):
    return max(minimum, min(x, maximum))

def enter():
    global image,opacify_num
    opacify_num = 0.0
    image = load_image("image\\Game_over.png")

def exit():
    global image, opacify_num
    del (image, opacify_num)


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    pass



def update(frame_time):
    global opacify_num

    opacify_num = clamp(0.0,opacify_num+0.002,1.0)
    print(opacify_num)

    if opacify_num == 1.0:
        delay(1)
        Global_data.Game_Over = True
        Game_framework.change_state(Title_state)


def draw(frame_time):
    # Game Rendering
    clear_canvas()
    # 해당 state draw 하고
    image.draw(400, 300, 800, 600)
    image.opacify(opacify_num)


    update_canvas()


