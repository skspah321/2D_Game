from pico2d import *
import Game_framework
import Global_data
import Character
import Dialogue_state
import Title_state


import Game_over_state

name = "Finsh_state"  # 엔딩

background = None
string = None
boy = None

opacify_num = 0.0

def clamp(minimum, x, maximum):
    return max(minimum, min(x, maximum))

def enter():
    global background, string, boy
    background = load_image("image\\Forest.png")
    string = load_image("image\\END.png")
    boy = Character.Character()
    boy.x, boy.y = 400, 600


def exit():
    global background, string, boy
    del(background, string, boy)


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_SPACE):
            Game_framework.push_state(Game_over_state)
        else:
            boy.handle_event(event)



def update(frame_time):
    global opacify_num
    if (boy.y < -22.0):
        #Game_framework.push_state(Dialogue_state)
        Global_data.Finish = True

    handle_events(frame_time)
    boy.update(frame_time)
    boy.x = clamp(280.0,boy.x,510.0)



    if(Global_data.Finish):
        opacify_num = clamp(0.0,opacify_num+0.001,1.0)
        string.opacify(opacify_num)

    if opacify_num == 1.0:
        delay(1)
        Game_framework.change_state(Title_state)



def draw_Finst_state():
    boy.draw()

def draw(frame_time):
    # Game Rendering
    clear_canvas()
    background.draw(400, 300, 800, 600)
    if(Global_data.Finish==0):
        draw_Finst_state()
    else:
        string.draw(400,270,200,200)
        string.opacify(opacify_num)

    update_canvas()


