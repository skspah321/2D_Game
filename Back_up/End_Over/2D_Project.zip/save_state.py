import Global_data
f = open('test.txt','w')
data = ['Global_data.character_x','Global_data.character_y']
f.write(data)

f.close()