import Game_framework
from pico2d import *

import Start_state

import Title_state

import Intro_state

import Finish_state



open_canvas()
Game_framework.run(Finish_state)  # enter를 실행한다.
close_canvas()