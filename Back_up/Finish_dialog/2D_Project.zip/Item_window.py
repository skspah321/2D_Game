from pico2d import *
import Game_framework
import Global_data

name = "Item_window"  # 아이템창

Background = None
key_list = None
keys = None


def enter():
    global Background,keys, count, key_list
    Background = load_image("item\\item_window.png")
    keys = [load_image("item\\1-1_key.png"),
            load_image("item\\nursing_key.png"),
            load_image("item\\library_key.png"),
            load_image("item\\office_key.png"),
            load_image("item\\entrace_key.png")]

    f = open("item\\key_box.json")
    key_list = json.load(f)

    count = 0

    if Global_data.Center_Key:
        count += 1
    if Global_data.Class_Key:
        count += 1
    if Global_data.Office_Key:
        count += 1
    if Global_data.Library_Key:
        count += 1
    if Global_data.Nursing_Key:
        count += 1


def exit():
    global Background,keys,count
    del(Background,keys,count)


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global Running
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type,event.key) == (SDL_KEYDOWN, SDLK_x):
            Game_framework.pop_state()


def update(frame_time):
    pass


def draw(frame_time):
    clear_canvas()
    Background.draw(400,300,800,600)

    for i in range(0,count):
        keys[i].draw(key_list["width"],key_list["height"]-(i*key_list["interval"]),
                     key_list["imagewidth"],key_list["imageheight"])

    update_canvas()



