import random
import json
import os

from pico2d import *
import Game_framework
import Global_data
import Start_state
import First_center_state
import First_right_state
import First_right_class_state
import First_left_state
import First_left_nursing_state
import Second_center_state
import Second_library_state
import Second_office_state

name = "Dialogue_state"  # 대화 상태

count = 0
dialogue = None
image = None


class Dialogue:
    def __init__(self):
        f = open("dialogue\\dialogue_box.json")
        self.dialogue = json.load(f)
        self.width = self.dialogue["width"]
        self.height = self.dialogue["height"]
        self.imagewidth = self.dialogue["imagewidth"]
        self.imageheight = self.dialogue["imageheight"]
        self.len = 0

        self.start_image = [load_image("dialogue\\start_01_dialogue.png"),
                            load_image("dialogue\\start_02_dialogue.png"),
                            load_image("dialogue\\start_03_dialogue.png")]

        self.map_image = [load_image("image\\maps.png")]

        self.lock_image = [load_image("dialogue\\lock_dialogue.png")]
        self.plant_image = [load_image("dialogue\\plant_dialogue.png")]

        self.desk_image = [load_image("dialogue\\desk_dialogue.png")]
        self.class_key_image = [load_image("dialogue\\1-1_door_dialogue.png")]

        self.class_book_image = [load_image("dialogue\\1-1_book_dialogue.png")]
        self.board_image = [load_image("dialogue\\1-1_board_dialogue.png")]
        self.nursing_key_image = [load_image("dialogue\\nurse_door_dialogue.png")]

        self.urn_image = [load_image("dialogue\\urn_dialogue.png")]
        self.cleaning_tool_image = [load_image("dialogue\\cleaning_tool_dialogue.png")]

        self.trash_image = [load_image("dialogue\\trash_dialogue.png")]
        self.machine_image = [load_image("dialogue\\machine_dialogue.png")]
        self.medicine_image = [load_image("dialogue\\nursing_medical_dialogue.png")]
        self.bed_image = [load_image("dialogue\\nursing_bed_dialogue.png")]
        self.library_key_image = [load_image("dialogue\\library_door_dialogue.png")]

        self.library_book_image = [load_image("dialogue\\library_book_dialogue.png")]
        self.library_desk_image = [load_image("dialogue\\library_desk_dialogue.png")]
        self.library_research_image = [load_image("dialogue\\library_research_dialogue.png")]
        self.office_key_image = [load_image("dialogue\\office_door_dialogue.png")]

        self.office_desk_image = [load_image("dialogue\\office_desk_dialogue.png")]
        self.office_board_image = [load_image("dialogue\\office_board_dialogue.png")]
        self.office_sink_image = [load_image("dialogue\\office_water_dialogue.png")]
        self.office_bottle_image = [load_image("dialogue\\office_bottle_dialogue.png")]
        self.entrace_key_image = [load_image("dialogue\\entrace_dialogue.png"),
                                  load_image("dialogue\\entrace2_dialogue.png")]

        self.state = Global_data.dialogue_state

        self.len = 1

        if self.state == 'start_game':
            self.len = 3

        if self.state == 'entrace_key':
            Global_data.Center_Key = True
            self.len = 2

        if self.state == 'class_key':
            Global_data.Class_Key = True

        if self.state == 'nurse_key':
            Global_data.Nursing_Key = True

        if self.state == 'library_key':
            Global_data.Library_Key = True

        if self.state == 'office_key':
            Global_data.Office_Key = True


        self.dialogue_list = []  # 대화를 리스트로 저장


        # 오브젝트 리스트에 모든 오브젝트저장, [ 이름, x좌표, y좌표, 너비, 높이 ]
        '''
        for obj_data in self.dialogue[self.state]:
            self.dialogue_list.append([obj_data["len"], obj_data["len"],
                                       obj_data["len"]])
                                       '''




def enter():
    global dialogue,image,count
    count = 0
    dialogue = Dialogue()
    if dialogue.state == 'start_game':
        image = dialogue.start_image[count]

    if dialogue.state == 'map':
        image = dialogue.map_image[count]

    if dialogue.state == 'door':
        image = dialogue.lock_image[count]

    if dialogue.state == 'plant':
        image = dialogue.plant_image[count]

    if dialogue.state == 'desk':
        image = dialogue.desk_image[count]

    if dialogue.state == 'class_key':
        image = dialogue.class_key_image[count]

    if dialogue.state == 'board':
        image = dialogue.board_image[count]

    if dialogue.state == 'class_book':
        image = dialogue.class_book_image[count]

    if dialogue.state == 'nurse_key':
        image = dialogue.nursing_key_image[count]

    if dialogue.state == 'urn':
        image = dialogue.urn_image[count]

    if dialogue.state == 'cleaning_tool':
        image = dialogue.cleaning_tool_image[count]

    if dialogue.state == 'trash':
        image = dialogue.trash_image[count]

    if dialogue.state == 'bed':
        image = dialogue.bed_image[count]

    if dialogue.state == 'library_key':
        image = dialogue.library_key_image[count]

    if dialogue.state == 'machine':
        image = dialogue.machine_image[count]

    if dialogue.state == 'medicine':
        image = dialogue.medicine_image[count]

    if dialogue.state == 'office_key':
        image = dialogue.office_key_image[count]

    if dialogue.state == 'library_book':
        image = dialogue.library_book_image[count]

    if dialogue.state == 'library_desk':
        image = dialogue.library_desk_image[count]

    if dialogue.state == 'library_research':
        image = dialogue.library_research_image[count]

    if dialogue.state == 'office_desk':
        image = dialogue.office_desk_image[count]

    if dialogue.state == 'office_board':
        image = dialogue.office_board_image[count]

    if dialogue.state == 'office_sink':
        image = dialogue.office_sink_image[count]

    if dialogue.state == 'office_bottle':
        image = dialogue.office_bottle_image[count]

    if dialogue.state == 'entrace_key':
        image = dialogue.entrace_key_image[count]


def exit():
    pass


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global count
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_z):
            count += 1
            if count >= dialogue.len:
                Game_framework.pop_state()



def update(frame_time):
    global image
    if count < dialogue.len:
        if dialogue.state == "start_game":
            image = dialogue.start_image[count]

        if dialogue.state == 'map':
            image = dialogue.map_image[count]

        if dialogue.state == 'door':
            image = dialogue.lock_image[count]

        if dialogue.state == 'class_key':
            image = dialogue.class_key_image[count]

        if dialogue.state == 'plant':
            image = dialogue.plant_image[count]

        if dialogue.state == 'desk':
            image = dialogue.desk_image[count]

        if dialogue.state == 'nurse_key':
            image = dialogue.nursing_key_image[count]

        if dialogue.state == 'class_book':
            image = dialogue.class_book_image[count]

        if dialogue.state == 'board':
            image = dialogue.board_image[count]

        if dialogue.state == 'urn':
            image = dialogue.urn_image[count]

        if dialogue.state == 'cleaning_tool':
            image = dialogue.cleaning_tool_image[count]

        if dialogue.state == 'trash':
            image = dialogue.trash_image[count]

        if dialogue.state == 'bed':
            image = dialogue.bed_image[count]

        if dialogue.state == 'library_key':
            image = dialogue.library_key_image[count]

        if dialogue.state == 'machine':
            image = dialogue.machine_image[count]

        if dialogue.state == 'medicine':
            image = dialogue.medicine_image[count]

        if dialogue.state == 'office_key':
            image = dialogue.office_key_image[count]

        if dialogue.state == 'library_book':
            image = dialogue.library_book_image[count]

        if dialogue.state == 'library_desk':
            image = dialogue.library_desk_image[count]

        if dialogue.state == 'library_research':
            image = dialogue.library_research_image[count]

        if dialogue.state == 'office_desk':
            image = dialogue.office_desk_image[count]

        if dialogue.state == 'office_board':
            image = dialogue.office_board_image[count]

        if dialogue.state == 'office_sink':
            image = dialogue.office_sink_image[count]

        if dialogue.state == 'office_bottle':
            image = dialogue.office_bottle_image[count]

        if dialogue.state == 'entrace_key':
            image = dialogue.entrace_key_image[count]

    #if count == Dialogue().dialogue_list[0][1]:
        #print("끝")


def draw(frame_time):
    # Game Rendering
    clear_canvas()

    if Global_data.Start_Game:
        Start_state.draw_push_state()

    if Global_data.First_Floor_center:
        First_center_state.draw_push_state()

    if Global_data.First_Floor_right:
        First_right_state.draw_push_state()

    if Global_data.First_Floor_right_class:
        First_right_class_state.draw_push_state()

    if Global_data.First_Floor_left:
        First_left_state.draw_push_state()

    if Global_data.First_Floor_left_nursing:
        First_left_nursing_state.draw_push_state()

    if Global_data.Second_Floor_center:
        Second_center_state.draw_push_state()

    if Global_data.Second_Floor_library:
        Second_library_state.draw_push_state()

    if Global_data.Second_Floor_office:
        Second_office_state.draw_push_state()

    if dialogue.state == 'map':
        image.draw(400,300,600,300)
    else:
        image.draw(dialogue.width,dialogue.height,dialogue.imagewidth,dialogue.imageheight)

    update_canvas()


