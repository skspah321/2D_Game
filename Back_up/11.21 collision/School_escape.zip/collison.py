from pico2d import *
import Character
import map_01

class collison
    def __init__(self,left_a,bottom_a,right_a,top_a):
        draw_rectangle(left_a,bottom_a,right_a,top_a)
        self.x =