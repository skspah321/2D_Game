import random
import json
import os

from pico2d import *
import Game_framework
import Global_data
import Character
import Enemy
import Start_Map
import First_center_state
import First_left_state
import First_right_state
import Second_center_state
import Start_state

name = "Dialogue_state"  # 대화 상태

count = 0
dialogue = None
image = None


class Dialogue:
    def __init__(self):
        f = open("dialogue\\dialogue_box.json")
        self.dialogue = json.load(f)
        self.width = self.dialogue["width"]
        self.height = self.dialogue["height"]
        self.imagewidth = self.dialogue["imagewidth"]
        self.imageheight = self.dialogue["imageheight"]
        self.len = 0

        self.start_image = [load_image("dialogue\\start_01_dialogue.png"),
                            load_image("dialogue\\start_02_dialogue.png"),
                            load_image("dialogue\\start_03_dialogue.png")]
        self.start_len = 3

        self.map_image = [load_image("image\\maps.png")]
        self.map_len = 1

        self.lock_image = [load_image("dialogue\\lock_dialogue.png")]
        self.lock_len = 1

        self.state = Global_data.dialogue_state

        if self.state == 'map':
            self.len = 1
        if self.state == 'start_game':
            self.len = 3
        if self.state == 'lock':
            self.len = 1

        self.dialogue_list = []  # 대화를 리스트로 저장


        # 오브젝트 리스트에 모든 오브젝트저장, [ 이름, x좌표, y좌표, 너비, 높이 ]
        '''
        for obj_data in self.dialogue[self.state]:
            self.dialogue_list.append([obj_data["len"], obj_data["len"],
                                       obj_data["len"]])
                                       '''




def enter():
    global dialogue,image,count
    count = 0
    dialogue = Dialogue()
    if dialogue.state == 'start_game':
        image = dialogue.start_image[count]

    if dialogue.state == 'map':
        image = dialogue.map_image[count]

    if dialogue.state == 'door':
        image = dialogue.lock_image[count]


def exit():
    pass


def pause():
    pass


def resume():
    pass


def handle_events(frame_time):
    global count
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_ESCAPE):
            Game_framework.quit()
        elif (event.type, event.key) == (SDL_KEYDOWN, SDLK_z):
            count += 1
            if count >= dialogue.len:
                Game_framework.pop_state()



def update(frame_time):
    global image
    if count < dialogue.len:
        if dialogue.state == "start_game":
            image = dialogue.start_image[count]

        if dialogue.state == 'map':
            image = dialogue.map_image[count]

        if dialogue.state == 'door':
            image = dialogue.lock_image[count]


    #if count == Dialogue().dialogue_list[0][1]:
        #print("끝")


def draw(frame_time):
    # Game Rendering
    clear_canvas()
    print(Global_data.Start_Game, Global_data.First_Floor_center)
    if Global_data.Start_Game:
        Start_state.draw_state()

    if Global_data.First_Floor_center:
        First_center_state.draw_push_state()

    if dialogue.state == 'map':
        image.draw(400,300,600,300)
    else:
        image.draw(dialogue.width,dialogue.height,dialogue.imagewidth,dialogue.imageheight)
    update_canvas()


